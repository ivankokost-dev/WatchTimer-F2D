package ua.polydream.f2d.watch;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

/**
 * F2D Таймер для годинника пілота (Galaxy Watch, Wear OS).
 * Quick button (або будь-яка програмована кнопка) — старт / пауза.
 * Дотик до екрана — свій «сів / злетів».
 * Утримання екрана на паузі чи після кінця — новий бій.
 * Developed by Ivan Kostiuk, Ukraine.
 */
public class MainActivity extends Activity {

    static final long BOUT_MS = 240_000;     // 4 хв, FAI F2D
    static final int PTS_PER_SEC = 2;

    // стан бою
    boolean started, running, air;
    long elapsed, airMs, lastTick;
    int lastWarnSec = -1;

    final Handler h = new Handler(Looper.getMainLooper());
    Vibrator vib;
    TimerView view;
    boolean resumed;

    final Runnable tick = new Runnable() {
        @Override public void run() {
            update();
            if (running) h.postDelayed(this, 100);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        view = new TimerView(this);
        setContentView(view);
        view.setOnClickListener(v -> toggleAir());
        view.setOnLongClickListener(v -> { reset(); return true; });
        load();
        if (running) { lastTick = SystemClock.elapsedRealtime(); h.post(tick); keepOn(true); }
    }

    // visible: таймер на екрані. Android перед onNewIntent ставить активність на паузу,
    // тому орієнтуємось на onStart/onStop, а не на onResume/onPause.
    boolean visible;
    String debug = ""; long debugUntil;

    @Override protected void onStart() { super.onStart(); visible = true; }
    @Override protected void onStop() { super.onStop(); visible = false; }
    @Override protected void onResume() { super.onResume(); resumed = true; view.invalidate(); }
    @Override protected void onPause() { super.onPause(); resumed = false; save(); }

    /** Quick button, призначена відкривати цей додаток: повторне натискання, коли таймер на екрані = старт / пауза. */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        showDebug("intent");
        if (visible) toggleStart();
    }

    /** Показує код будь-якої фізичної кнопки — щоб дізнатися, що надсилає Quick button. */
    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) showDebug("key " + e.getKeyCode());
        return super.dispatchKeyEvent(e);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        if (e.getRepeatCount() > 0) return true;
        switch (keyCode) {
            case KeyEvent.KEYCODE_STEM_PRIMARY:
            case KeyEvent.KEYCODE_STEM_1:
            case KeyEvent.KEYCODE_STEM_2:
            case KeyEvent.KEYCODE_STEM_3:
                toggleStart();
                return true;
        }
        return super.onKeyDown(keyCode, e);
    }

    /** Нижня кнопка «Назад» = старт / пауза. Вийти з таймера — верхньою кнопкою «Додому». */
    @Override
    public void onBackPressed() {
        toggleStart();
    }

    void showDebug(String s) { debug = s; debugUntil = SystemClock.elapsedRealtime() + 2500; view.invalidate(); h.postDelayed(view::invalidate, 2600); }

    // ---------- дії ----------
    void toggleStart() {
        if (elapsed >= BOUT_MS) return;
        update();
        if (!started) {                 // старт: модель вважається в повітрі одразу
            started = true; air = true; running = true;
            vibrate(new long[]{0, 600});
        } else {
            running = !running;
            vibrate(running ? new long[]{0, 300} : new long[]{0, 100, 120, 100});
        }
        lastTick = SystemClock.elapsedRealtime();
        keepOn(running);
        if (running) { h.removeCallbacks(tick); h.post(tick); }
        save(); view.invalidate();
    }

    void toggleAir() {
        if (!started || elapsed >= BOUT_MS) { toast(R.string.hint_start); pulse(40); return; }
        update();
        air = !air;
        vibrate(air ? new long[]{0, 150} : new long[]{0, 70, 90, 70});
        save(); view.invalidate();
    }

    void reset() {
        if (running) { toast(R.string.toast_pause_first); pulse(80); return; }
        started = running = air = false; elapsed = airMs = 0; lastWarnSec = -1;
        vibrate(new long[]{0, 200, 120, 200});
        toast(R.string.toast_reset);
        keepOn(false); save(); view.invalidate();
    }

    void update() {
        if (!running) return;
        long now = SystemClock.elapsedRealtime();
        long dt = Math.min(now - lastTick, BOUT_MS - elapsed);
        lastTick = now;
        elapsed += dt;
        if (air) airMs += dt;
        int rem = (int) ((BOUT_MS - elapsed + 999) / 1000);
        if (rem != lastWarnSec) {
            lastWarnSec = rem;
            if (rem == 60) vibrate(new long[]{0, 250, 150, 250});                 // 1 хв: 2 довгі
            else if (rem == 30) vibrate(new long[]{0, 250, 150, 250, 150, 250});  // 30 с: 3 довгі
            else if (rem <= 10 && rem >= 1) pulse(rem <= 3 ? 160 : 70);           // останні 10 с: щосекунди
        }
        if (elapsed >= BOUT_MS) {
            running = false;
            vibrate(new long[]{0, 1200});                                          // кінець
            keepOn(false); save();
        }
        view.invalidate();
    }

    // ---------- допоміжне ----------
    void vibrate(long[] pattern) {
        if (vib == null) return;
        vib.vibrate(VibrationEffect.createWaveform(pattern, -1));
    }
    void pulse(long ms) { vibrate(new long[]{0, ms}); }
    void toast(int res) { Toast.makeText(this, res, Toast.LENGTH_SHORT).show(); }
    void keepOn(boolean on) {
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    void save() {
        getSharedPreferences("bout", MODE_PRIVATE).edit()
            .putBoolean("started", started).putBoolean("running", running).putBoolean("air", air)
            .putLong("elapsed", elapsed).putLong("airMs", airMs)
            .putLong("lastTick", lastTick).putLong("boot", System.currentTimeMillis() - SystemClock.elapsedRealtime())
            .apply();
    }
    void load() {
        SharedPreferences p = getSharedPreferences("bout", MODE_PRIVATE);
        started = p.getBoolean("started", false); running = p.getBoolean("running", false); air = p.getBoolean("air", false);
        elapsed = p.getLong("elapsed", 0); airMs = p.getLong("airMs", 0);
        long savedBoot = p.getLong("boot", 0), nowBoot = System.currentTimeMillis() - SystemClock.elapsedRealtime();
        // якщо годинник перезавантажувався, відлік від старої мітки вже некоректний — ставимо на паузу
        if (running && Math.abs(savedBoot - nowBoot) > 5000) running = false;
        lastTick = running ? p.getLong("lastTick", SystemClock.elapsedRealtime()) : SystemClock.elapsedRealtime();
        if (running) update();
    }

    static String fmt(long ms) {
        long s = Math.max(0, ms) / 1000;
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    // ---------- екран ----------
    class TimerView extends View {
        final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG), track = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint big = new Paint(Paint.ANTI_ALIAS_FLAG), mid = new Paint(Paint.ANTI_ALIAS_FLAG), small = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint pill = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF arc = new RectF(), pr = new RectF();
        final int GREEN = 0xFF5AD27E, AMBER = 0xFFF2B84B, RED = 0xFFFF5A4E, GREY = 0xFF6B746E, WHITE = 0xFFEEF2EF;

        TimerView(Context c) {
            super(c);
            setBackgroundColor(Color.BLACK);
            setHapticFeedbackEnabled(false);
            ring.setStyle(Paint.Style.STROKE); ring.setStrokeCap(Paint.Cap.ROUND);
            track.setStyle(Paint.Style.STROKE); track.setColor(0xFF1F2522);
            Typeface num = Typeface.create("sans-serif-condensed", Typeface.BOLD);
            big.setTypeface(num); big.setTextAlign(Paint.Align.CENTER); big.setFontFeatureSettings("tnum");
            mid.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); mid.setTextAlign(Paint.Align.CENTER);
            small.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)); small.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), hgt = getHeight(), cx = w / 2f, cy = hgt / 2f, s = Math.min(w, hgt);
            long rem = BOUT_MS - elapsed;
            boolean over = elapsed >= BOUT_MS;
            int stateCol = !started ? GREY : over ? RED : !running ? AMBER : rem <= 30_000 ? RED : GREEN;

            // кільце залишку часу
            float sw = s * 0.045f, inset = sw / 2f + s * 0.02f;
            ring.setStrokeWidth(sw); track.setStrokeWidth(sw);
            arc.set(inset, inset, w - inset, hgt - inset);
            c.drawArc(arc, 0, 360, false, track);
            ring.setColor(stateCol);
            c.drawArc(arc, -90, 360f * rem / BOUT_MS, false, ring);

            // статус
            String st = !started ? getString(R.string.ready) : over ? getString(R.string.over)
                    : !running ? getString(R.string.paused) : air ? getString(R.string.air) : getString(R.string.ground);
            int stCol = !started ? GREY : over ? RED : !running ? AMBER : air ? GREEN : GREY;
            mid.setTextSize(s * 0.075f);
            float tw = mid.measureText(st) + s * 0.08f, ty = cy - s * 0.25f;
            pr.set(cx - tw / 2, ty - s * 0.07f, cx + tw / 2, ty + s * 0.035f);
            pill.setColor((stCol & 0x00FFFFFF) | 0x33000000);
            c.drawRoundRect(pr, s * 0.06f, s * 0.06f, pill);
            mid.setColor(stCol);
            c.drawText(st, cx, ty, mid);

            // великий залишок часу
            big.setTextSize(s * 0.36f);
            big.setColor(over ? RED : running && rem <= 30_000 ? RED : WHITE);
            c.drawText(fmt(rem + 999), cx, cy + s * 0.12f, big);

            // свій час польоту і бали за нього
            small.setTextSize(s * 0.07f); small.setColor(0xFFB8C0BA);
            c.drawText(getString(R.string.flight, fmt(airMs), (airMs / 1000) * PTS_PER_SEC), cx, cy + s * 0.25f, small);

            // підказка
            small.setTextSize(s * 0.058f); small.setColor(GREY);
            String hint = !started ? getString(R.string.hint_start) : running ? getString(R.string.hint_run) : getString(R.string.hint_hold);
            c.drawText(hint, cx, cy + s * 0.355f, small);

            // службовий рядок: код натиснутої кнопки (зникає за 2,5 с)
            if (SystemClock.elapsedRealtime() < debugUntil) {
                small.setColor(AMBER); small.setTextSize(s * 0.06f);
                c.drawText(debug, cx, cy - s * 0.36f, small);
            }
        }
    }
}
